# Glossary (LFDT)

**Contributor License Agreement (CLA):** A legal agreement between a contributor and a project, 
granting rights to use, modify, and distribute contributions. Some projects instead use a Developer Certificate of Origin (DCO).


---
*Attribution:* Adapted from the CNCF Contributors site (CC BY 4.0) and related TAG materials (Apache-2.0). 
Edits for LFDT terminology and links by the LF Decentralized Trust community.

