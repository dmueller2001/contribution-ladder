# Mentoring (LFDT)

Learn and grow through mentorship: mentee onboarding, mentor guides, project selection, and timelines.  
(TODO: Add LFDT mentoring program details.)


---
*Attribution:* Adapted from the CNCF Contributors site (CC BY 4.0) and related TAG materials (Apache-2.0). 
Edits for LFDT terminology and links by the LF Decentralized Trust community.

