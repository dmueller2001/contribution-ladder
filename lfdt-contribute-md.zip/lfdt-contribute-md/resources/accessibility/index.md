# Accessibility (LFDT)

Guidance and resources to make projects accessible to everyone, including assistive technology users.  
(TODO: Link to LFDT accessibility resources and issue labels.)


---
*Attribution:* Adapted from the CNCF Contributors site (CC BY 4.0) and related TAG materials (Apache-2.0). 
Edits for LFDT terminology and links by the LF Decentralized Trust community.

