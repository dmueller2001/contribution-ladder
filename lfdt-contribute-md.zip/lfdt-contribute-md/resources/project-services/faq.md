# Project Services FAQ (LFDT)

**Where do I request support?**  
TODO: Add Service Desk link and expected response times.

**How much budget is available?**  
Budgets are handled case‑by‑case. TODO: link to LFDT policy.

**How do I donate a project to LFDT?**  
TODO: link to LFDT intake/onboarding docs.


---
*Attribution:* Adapted from the CNCF Contributors site (CC BY 4.0) and related TAG materials (Apache-2.0). 
Edits for LFDT terminology and links by the LF Decentralized Trust community.

