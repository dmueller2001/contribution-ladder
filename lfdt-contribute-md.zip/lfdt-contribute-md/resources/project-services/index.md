# Project Services (LFDT)

A collection of services LFDT **aims** to offer or coordinate for projects.  
(**Note:** Many links are TODO while LFDT service pages are finalized.)

- **Service Desk:** TODO: link/email
- **Security Support:** TODO
- **Brand/Design:** TODO
- **Website/Docs Hosting:** TODO
- **Infra/CI:** TODO
- **Budgeting & Events:** TODO

See the [FAQ](faq.md).


---
*Attribution:* Adapted from the CNCF Contributors site (CC BY 4.0) and related TAG materials (Apache-2.0). 
Edits for LFDT terminology and links by the LF Decentralized Trust community.

