# Contributing to this Site (LFDT)

Quick start for content updates:
1. Fork the repo on GitHub.
2. Edit Markdown files and open a Pull Request.
3. Netlify/GitHub Pages will build a preview for review (if configured).

If your PR is a work‑in‑progress, open it as a Draft PR.


---
*Attribution:* Adapted from the CNCF Contributors site (CC BY 4.0) and related TAG materials (Apache-2.0). 
Edits for LFDT terminology and links by the LF Decentralized Trust community.

