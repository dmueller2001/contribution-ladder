# Maintainers' Circle (LFDT)

A forum for maintainers to share practices on sustainability, contributor growth,
governance, and inclusiveness. (TODO: add LFDT call cadence and links.)


---
*Attribution:* Adapted from the CNCF Contributors site (CC BY 4.0) and related TAG materials (Apache-2.0). 
Edits for LFDT terminology and links by the LF Decentralized Trust community.

