# Governance Overview (LFDT)

A clear governance model helps contributors understand how to participate, how decisions are made,
and what leadership paths exist.

**Recommended:** Document roles, decision‑making, elections, and escalation paths in your repo.


---
*Attribution:* Adapted from the CNCF Contributors site (CC BY 4.0) and related TAG materials (Apache-2.0). 
Edits for LFDT terminology and links by the LF Decentralized Trust community.

