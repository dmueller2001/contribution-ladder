# Templates (LFDT)

Starter templates for common project docs (adapt for LFDT):

- `CODE_OF_CONDUCT.md` (TODO: link to LFDT‑preferred baseline)
- `CONTRIBUTING.md`
- `GOVERNANCE.md`
- `SECURITY.md`
- `ADOPTERS.md`


---
*Attribution:* Adapted from the CNCF Contributors site (CC BY 4.0) and related TAG materials (Apache-2.0). 
Edits for LFDT terminology and links by the LF Decentralized Trust community.

