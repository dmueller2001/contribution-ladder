# Contribute to LFDT Projects

LFDT offers multiple ways to start contributing, foundation‑wide and project‑specific.

- [Getting started](getting-started.md)
- [Finding a project](finding-a-project.md)
- [Ways to contribute](ways-to-contribute.md)


---
*Attribution:* Adapted from the CNCF Contributors site (CC BY 4.0) and related TAG materials (Apache-2.0). 
Edits for LFDT terminology and links by the LF Decentralized Trust community.

