# Finding a Project (LFDT)

1. Browse LFDT projects (TODO: add canonical LFDT projects index).
2. Check labels like `good first issue` and `help wanted`.
3. Join chat, mailing list, or community calls (see each project's README).


---
*Attribution:* Adapted from the CNCF Contributors site (CC BY 4.0) and related TAG materials (Apache-2.0). 
Edits for LFDT terminology and links by the LF Decentralized Trust community.

