This content was adapted for LFDT from the CNCF Contributors site (contribute.cncf.io)
and the `cncf/tag-contributor-strategy` repository.

- Documentation on contribute.cncf.io is distributed under **CC BY 4.0**.
- The `tag-contributor-strategy` repository code/assets are licensed under **Apache-2.0**.

Per CC BY 4.0, attribution is provided to "The CNCF Authors".
Trademarks and logos remain the property of their respective owners.
